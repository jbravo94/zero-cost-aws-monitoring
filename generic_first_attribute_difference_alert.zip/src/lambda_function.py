import json
import logging
import boto3

LOGGER = logging.getLogger()
LOGGER.setLevel(logging.INFO)

client = boto3.client('sns')

topic_arn='arn:aws:sns:eu-central-1:367906864559:generic_alert_topic'

def lambda_handler(event, context):

    messages = ""

    LOGGER.info('Received Event: %s', event)
    for rec in event['Records']:
        LOGGER.info('Record: %s', rec)

        instance_name = rec['dynamodb']['Keys']['instance_name']['S']

        old_stats_dict = {}

        old_stats = json.loads(rec['dynamodb']['OldImage']['statistics']['S'])

        for channel_stats in old_stats['list']['channelStatistics']:
            channel_id = channel_stats["channelId"]
            error = channel_stats["error"]

            old_stats_dict[channel_id] = error

        new_stats = json.loads(rec['dynamodb']['NewImage']['statistics']['S'])

        for channel_stats in new_stats['list']['channelStatistics']:
            channel_id = channel_stats["channelId"]
            error = channel_stats["error"]

            if old_stats_dict.get(channel_id) is not None and error > old_stats_dict[channel_id]:
                messages += (instance_name + " reported that channel " + channel_id + " has errorous messages.\n")

    if messages != "":
        response = client.publish(TopicArn=topic_arn, Message=messages)
        LOGGER.info('Published to SNS topic: %s', response)

    return {
        'statusCode': 200,
        'body': json.dumps('Successfully executed!')
    }
